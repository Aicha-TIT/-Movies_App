<?php

/**
 * This file has been auto-generated
 * by the Symfony Routing Component.
 */

return [
    false, // $matchHost
    [ // $staticRoutes
        '/' => [[['_route' => 'index', '_controller' => 'App\\Controller\\MovieController::index'], null, null, null, false, false, null]],
        '/movies' => [[['_route' => 'movie_index', '_controller' => 'App\\Controller\\MovieController::index'], null, null, null, false, false, null]],
        '/movies/search' => [[['_route' => 'movie_search', '_controller' => 'App\\Controller\\MovieController::search'], null, null, null, false, false, null]],
    ],
    [ // $regexpList
        0 => '{^(?'
                .'|/_error/(\\d+)(?:\\.([^/]++))?(*:35)'
                .'|/movies/(?'
                    .'|edit/([^/]++)(*:66)'
                    .'|delete/([^/]++)(*:88)'
                .')'
            .')/?$}sDu',
    ],
    [ // $dynamicRoutes
        35 => [[['_route' => '_preview_error', '_controller' => 'error_controller::preview', '_format' => 'html'], ['code', '_format'], null, null, false, true, null]],
        66 => [[['_route' => 'movie_edit', '_controller' => 'App\\Controller\\MovieController::edit'], ['id'], null, null, false, true, null]],
        88 => [
            [['_route' => 'movie_delete', '_controller' => 'App\\Controller\\MovieController::delete'], ['id'], null, null, false, true, null],
            [null, null, null, null, false, false, 0],
        ],
    ],
    null, // $checkCondition
];
