<?php

// src/Command/ImportMoviesCommand.php

namespace App\Command;

use Doctrine\ORM\EntityManagerInterface;
use Symfony\Component\Console\Command\Command;
use Symfony\Component\Console\Input\InputInterface;
use Symfony\Component\Console\Output\OutputInterface;
use Symfony\Contracts\HttpClient\HttpClientInterface; 
use App\Entity\Movie;

class ImportMoviesCommand extends Command
{
    private $entityManager;
    private $httpClient;

    public function __construct(EntityManagerInterface $entityManager, HttpClientInterface $httpClient)
    {
        parent::__construct();

        $this->entityManager = $entityManager;
        $this->httpClient = $httpClient;
    }

    protected function configure()
    {
        $this
            ->setName('app:import:movies')
            ->setDescription('Import popular movies from TMDb API');
    }

    protected function execute(InputInterface $input, OutputInterface $output): int
    {
        // Use TMDb API key
        $apiKey = 'dc4a1a30e13042657cc4081b0a16bf8f';
        $url = 'https://api.themoviedb.org/3/movie/popular?api_key=' . $apiKey;

        try {
           // Fetch data from TMDb API
            $response = $this->httpClient->request('GET', $url);
            $data = $response->toArray();

            // Import movies into the database
            foreach ($data['results'] as $movieData) {
                $movie = new Movie();
                $movie->setTitle($movieData['title']);
                $movie->setYear(\DateTime::createFromFormat('Y-m-d', $movieData['release_date'])->format('Y'));
                $movie->setDescription($movieData['overview']);
                $movie->setRating($movieData['vote_average']);

                // You need to add the logic to set the image field based on your data

                // Persist the movie entity
                $this->entityManager->persist($movie);
            }

            // Flush the changes to the database
            $this->entityManager->flush();

            $output->writeln('Movies imported successfully.');
        } catch (\Exception $exception) {
            // Handle exceptions, log, or output an error message
            $output->writeln('Error importing movies: ' . $exception->getMessage());

            return Command::FAILURE;
        }

        return Command::SUCCESS;
    }
}