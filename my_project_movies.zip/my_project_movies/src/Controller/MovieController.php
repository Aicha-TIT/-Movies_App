<?php

namespace App\Controller;

use App\Entity\Movie;
use App\Form\EditMovieType;
use Doctrine\ORM\EntityManagerInterface;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\Request; 
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Annotation\Route;
use App\Form\SearchMovieType;


class MovieController extends AbstractController
{
    private $entityManager;

    public function __construct(EntityManagerInterface $entityManager)
    {
        $this->entityManager = $entityManager;
    }

    /**
     * @Route("/movies", name="movie_index")
     */
    public function index(): Response
    {
        $movies = $this->entityManager->getRepository(Movie::class)->findAll();

        return $this->render('movie/index.html.twig', [
            'movies' => $movies,
        ]);
    }

    /**
     * @Route("/movies/search", name="movie_search")
     */
    public function search(Request $request): Response
    {
        $form = $this->createForm(SearchMovieType::class);
        $form->handleRequest($request);

        if ($form->isSubmitted() && $form->isValid()) {
            // Perform search logic based on the form data

            // For example:
            $keyword = $form->get('keyword')->getData();
            $movies = $this->entityManager->getRepository(Movie::class)->findByTitle($keyword);

            return $this->render('movie/search_results.html.twig', [
                'movies' => $movies,
            ]);
        }

        return $this->render('movie/search.html.twig', [
            'searchForm' => $form->createView(),
        ]);
    }

    /**
     * @Route("/movies/edit/{id}", name="movie_edit")
     */
    public function edit(Request $request, int $id): Response
    {
        $movie = $this->entityManager->getRepository(Movie::class)->find($id);

        if (!$movie) {
            throw $this->createNotFoundException('Movie not found');
        }

        $form = $this->createForm(EditMovieType::class, $movie);
        $form->handleRequest($request);

        if ($form->isSubmitted() && $form->isValid()) {
            $this->entityManager->flush();

            return $this->redirectToRoute('movie_index');
        }

        return $this->render('movie/edit.html.twig', [
            'form' => $form->createView(),
        ]);
    }

    /**
     * @Route("/movies/delete/{id}", name="movie_delete")
     */
    public function delete(int $id): Response
    {
        $movie = $this->entityManager->getRepository(Movie::class)->find($id);

        if (!$movie) {
            throw $this->createNotFoundException('Movie not found');
        }

        $this->entityManager->remove($movie);
        $this->entityManager->flush();

        return $this->redirectToRoute('movie_index');
    }
}
